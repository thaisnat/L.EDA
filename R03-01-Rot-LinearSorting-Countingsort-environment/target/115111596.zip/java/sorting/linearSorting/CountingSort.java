package sorting.linearSorting;

import sorting.AbstractSorting;

/**
 * Classe que implementa a estratégia de Counting Sort vista em sala. Procure
 * evitar desperdicio de memoria alocando o array de contadores com o tamanho
 * sendo o máximo inteiro presente no array a ser ordenado.
 * 
 */
public class CountingSort extends AbstractSorting<Integer> {

	@Override
	public void sort(Integer[] array, int leftIndex, int rightIndex) {
		
if(leftIndex < rightIndex && array[leftIndex] != null && array.length > 0){
			
			int tamArray = rightIndex+1;
			int tamAux = (retornaMaior(array,leftIndex, rightIndex)+1);
		
			int[] aResposta = new int[tamArray];
			int[] aAux = new int[tamAux];
			
			for (int iArray = leftIndex; iArray <= rightIndex; iArray++) {
				aAux[array[iArray]]++;
			}
			
			for (int iAux = 1; iAux < tamAux; iAux++) {
				aAux[iAux] += aAux[iAux-1];
			}
			
			
			for (int iArray = leftIndex; iArray <= rightIndex; iArray++) {
				int posicao = array[iArray];
				int posicaoAux = aAux[posicao]-1;
				
				aResposta[posicaoAux] = posicao;
				aAux[posicao]--;
			}
			
			for (int iResposta = 0; iResposta < aResposta.length; iResposta++) {
				array[iResposta] = aResposta[iResposta];
			}
				
		}
		
	}

	private int retornaMaior(Integer[] array, int leftIndex, int rightIndex) {
		int maior = array[leftIndex];
		for (int iArray = leftIndex+1; iArray <= rightIndex; iArray++) {
			if(array[iArray] > maior){
				maior = array[iArray];
			}
		}
		return maior;
	}

}
