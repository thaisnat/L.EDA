package sorting.linearSorting;

import sorting.AbstractSorting;

/**
 * Classe que implementa do Counting Sort vista em sala. Desta vez este
 * algoritmo deve satisfazer os seguitnes requisitos: - Alocar o tamanho minimo
 * possivel para o array de contadores (C) - Ser capaz de ordenar arrays
 * contendo numeros negativos
 */
public class ExtendedCountingSort extends AbstractSorting<Integer> {

	@Override
	public void sort(Integer[] array, int leftIndex, int rightIndex) {
if(leftIndex < rightIndex && array[leftIndex] != null && array.length > 0){
			
			int menor = retornaMenor(array, leftIndex, rightIndex);
			int maior = retornaMaior(array, leftIndex, rightIndex);
			
			int tamArray = (rightIndex-leftIndex)+1;
			int tamAux = (maior-menor)+1;
		
			int[] aResposta = new int[tamArray];
			int[] aAux = new int[tamAux];
			
			if (menor >= 0) {
				for (int iArray = leftIndex; iArray <= rightIndex; iArray++) {
					aAux[array[iArray] - menor]++;
				}
				
				for (int iAux = 1; iAux < tamAux; iAux++) {
					aAux[iAux] += aAux[iAux-1];
				}
				
				for (int iArray = leftIndex; iArray <= rightIndex; iArray++) {
					aResposta[aAux[array[iArray] - menor] -1] = array[iArray];
					aAux[array[iArray]-menor]--;
				}
			}else{
				
				for (int iArray = leftIndex; iArray <= rightIndex; iArray++) {
					aAux[array[iArray] - Math.abs(menor)]++;
				}
				
				for (int iAux = 1; iAux < tamAux; iAux++) {
					aAux[iAux] += aAux[iAux-1];
				}
				
				for (int iArray = leftIndex; iArray <= rightIndex; iArray++) {
					menor = Math.abs(menor);
					aResposta[aAux[array[iArray] - menor] -1] = array[iArray];
					aAux[array[iArray]-menor-1]--;
				}
			}
			
			
			for (int iResposta = 0; iResposta < aResposta.length; iResposta++) {
				array[iResposta] = aResposta[iResposta];
			}		
		}
	}

	private int retornaMaior(Integer[] array, int leftIndex, int rightIndex) {
		int maior = array[leftIndex];
		for (int iArray = leftIndex+1; iArray <= rightIndex; iArray++) {
			if(array[iArray] >= maior){
				maior = array[iArray];
			}
		}
		return maior;
	}

	private int retornaMenor(Integer[] array, int leftIndex, int rightIndex) {
		int menor = array[leftIndex];
		for (int iArray = leftIndex+1; iArray <= rightIndex; iArray++) {
			if(array[iArray] <= menor){
				menor = array[iArray];
			}
		}
		return menor;
	}



}
